

public class Main {

    public static void main(String[] args) {


        Parqueadero parqueadero = new Parqueadero();


        System.out.println("Tarifa inicial: " + parqueadero.darTarifa());


        String placa1 = "placa1";
        String placa2 = "placa2";
        String placa3 = "placa33";

        int puesto2 = parqueadero.entrarCarro(placa1);
        int puesto3 = parqueadero.entrarCarro(placa2);
        int puesto1 = parqueadero.entrarCarro(placa3);

        System.out.println("Carro con placa " + placa2 + " en puesto: " + puesto2);
        System.out.println("Carro con placa " + placa3 + " en puesto: " + puesto3);
        System.out.println("Carro con placa " + placa1 + " en puesto: " + puesto1);


        parqueadero.avanzarHora();
        System.out.println("Hora actual en el parqueadero: " + parqueadero.darHoraActual());


        int montoAPagar = parqueadero.sacarCarro(placa1);
        System.out.println("Monto a pagar por el carro con placa " + placa1 + ": " + montoAPagar);


        System.out.println("Monto total en la caja: " + parqueadero.darMontoCaja());


        System.out.println("Puestos libres: " + parqueadero.calcularPuestosLibres());


        parqueadero.cambiarTarifa(1500);
        System.out.println("Nueva tarifa: " + parqueadero.darTarifa());


        System.out.println("Placa en el puesto " + puesto1 + ": " + parqueadero.darPlacaCarro(puesto1));
        System.out.println("Hay carro en esta posicion? " + puesto2 + ": " + parqueadero.darPlacaCarro(puesto2));
        System.out.println("Placa en el puesto " + puesto3 + ": " + parqueadero.darPlacaCarro(puesto3));
    }
}