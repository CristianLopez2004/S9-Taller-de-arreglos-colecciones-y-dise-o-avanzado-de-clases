

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Parqueadero parqueadero = new Parqueadero();

        // Añadir carritoos
        parqueadero.entrarCarro("placa1");
        parqueadero.avanzarHora();
        parqueadero.entrarCarro("placa22");
        parqueadero.avanzarHora();
        parqueadero.avanzarHora();
        parqueadero.entrarCarro("BPplaca3");
        parqueadero.avanzarHora();
        parqueadero.avanzarHora();
        parqueadero.avanzarHora();
        parqueadero.entrarCarro("placa4");

        // paraa  el métodooo darTiempoPromedio
        double tiempoPromedio = parqueadero.darTiempoPromedio();
        System.out.println("Tiempo promedio de los carros en el parqueadero: " + tiempoPromedio);

        // pruebar el método hayCarroMasDeOchoHoras
        boolean masDeOchoHoras = parqueadero.hayCarroMasDeOchoHoras();
        System.out.println("Hay algún carro que lleva más de ocho horas parqueado: " + masDeOchoHoras);

        // método darCarrosMasDeTresHorasParqueados
        ArrayList<Carro> carrosMasDeTresHoras = parqueadero.darCarrosMasDeTresHorasParqueados();
        System.out.println("Carros que llevan más de tres horas parqueados:");
        for (Carro carro : carrosMasDeTresHoras) {
            System.out.println("Placa: " + carro.darPlaca());
        }

        // Paraa método hayCarrosPlacaIgual y PB

        boolean placasIguales = parqueadero.hayCarrosPlacaIgual();
        System.out.println("Hay carros con placas iguales: " + placasIguales);
        int cantidadPB = parqueadero.contarCarrosQueComienzanConPlacaPB();
        System.out.println("Cantidad de carros con placa PB: " + cantidadPB);

        // metodio hayCarroCon24Horas()
        boolean hayCarro24Horas = parqueadero.hayCarroCon24Horas();
        if (hayCarro24Horas) {
            System.out.println("Hay carro parqueado por 24 o más horas: Sí.");
        } else {
            System.out.println("Hay carro parqueado por 24 o más horas: No.");
        }
        //metodounoo
        String resultadoMetodo1 = parqueadero.metodouno();
        System.out.println("Resultado : " + resultadoMetodo1);

        // metodou desocuparParqueadero()
        int carrosSacados = parqueadero.desocuparParqueadero();
        System.out.println("Cantidad de carros sacados: " + carrosSacados);

        // metodo2
        String resultadoMetodo2 = parqueadero.metododos();
        System.out.println("Resultado : " + resultadoMetodo2);


    }
}
